// تطبيق المتجر الرئيسي
class StoreApp {
    constructor() {
        this.currentUser = null;
        this.products = [];
        this.orders = [];
        this.users = [];
        this.currentProduct = null;
        this.init();
    }

    init() {
        this.loadData();
        this.setupEventListeners();
        this.checkUserAuth();
        this.displayProducts();
        this.updateUI();
    }

    // تحميل البيانات
    loadData() {
        // تحميل المنتجات
        this.products = JSON.parse(localStorage.getItem('products')) || this.getDefaultProducts();
        
        // تحميل الطلبات
        this.orders = JSON.parse(localStorage.getItem('orders')) || [];
        
        // تحميل المستخدمين
        this.users = JSON.parse(localStorage.getItem('users')) || this.getDefaultUsers();
        
        // حفظ البيانات إذا كانت جديدة
        localStorage.setItem('products', JSON.stringify(this.products));
        localStorage.setItem('users', JSON.stringify(this.users));
        localStorage.setItem('orders', JSON.stringify(this.orders));
    }

    // المنتجات الافتراضية
    getDefaultProducts() {
        return [
            {
                id: 1,
                name: "باقة إنترنت 10GB",
                category: "خدمات",
                price: 45.00,
                icon: "fa-wifi",
                description: "باقة إنترنت عالية السرعة لمدة 30 يوم مع دعم كافة الأجهزة",
                color: "#2196F3",
                status: "active"
            },
            {
                id: 2,
                name: "شحن رصيد لعبة",
                category: "ألعاب",
                price: 25.00,
                icon: "fa-gamepad",
                description: "رصيد لجميع الألعاب الشهيرة مثل ببجي و فورتنايت",
                color: "#FF6B6B",
                status: "active"
            },
            {
                id: 3,
                name: "تطبيق بريميوم",
                category: "تطبيقات",
                price: 99.00,
                icon: "fa-mobile-alt",
                description: "اشتراك سنوي للتطبيقات المميزة بدون إعلانات",
                color: "#4CAF50",
                status: "active"
            },
            {
                id: 4,
                name: "باقة مكالمات",
                category: "اتصالات",
                price: 30.00,
                icon: "fa-phone",
                description: "1000 دقيقة لمختلف الشبكات لمدة شهر كامل",
                color: "#9C27B0",
                status: "active"
            }
        ];
    }

    // المستخدمين الافتراضيين
    getDefaultUsers() {
        return [
            {
                id: 1,
                username: "user1",
                password: "user123",
                name: "أحمد محمد",
                balance: 150.00,
                role: "user"
            },
            {
                id: 2,
                username: "user2",
                password: "user123",
                name: "محمد علي",
                balance: 75.00,
                role: "user"
            }
        ];
    }

    // إعداد المستمعين للأحداث
    setupEventListeners() {
        // تسجيل الدخول
        const loginForm = document.getElementById('loginForm');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleLogin();
            });
        }

        // تأكيد الشراء
        const confirmBtn = document.getElementById('confirmPurchase');
        if (confirmBtn) {
            confirmBtn.addEventListener('click', () => {
                this.confirmPurchase();
            });
        }

        // أزرار الإغلاق
        const closeLogin = document.getElementById('closeLogin');
        const closeBalance = document.getElementById('closeBalance');
        const closePurchase = document.getElementById('closePurchase');
        const loginBtn = document.getElementById('loginBtn');
        const addBalanceBtn = document.getElementById('addBalanceBtn');

        if (closeLogin) closeLogin.addEventListener('click', () => this.closeLoginModal());
        if (closeBalance) closeBalance.addEventListener('click', () => this.closeAddBalanceModal());
        if (closePurchase) closePurchase.addEventListener('click', () => this.closePurchaseModal());
        if (loginBtn) loginBtn.addEventListener('click', () => this.showLoginModal());
        if (addBalanceBtn) addBalanceBtn.addEventListener('click', () => this.showAddBalanceModal());

        // إغلاق النوافذ عند النقر خارجها
        window.addEventListener('click', (e) => {
            const modals = document.querySelectorAll('.modal');
            modals.forEach(modal => {
                if (e.target === modal) {
                    modal.style.display = 'none';
                }
            });
        });
    }

    // التحقق من تسجيل الدخول
    checkUserAuth() {
        const userData = localStorage.getItem('currentUser');
        if (userData) {
            this.currentUser = JSON.parse(userData);
            this.updateUI();
        }
    }

    // معالجة تسجيل الدخول
    handleLogin() {
        const username = document.getElementById('loginUsername').value;
        const password = document.getElementById('loginPassword').value;

        const user = this.users.find(u => u.username === username && u.password === password);
        
        if (user) {
            this.currentUser = user;
            localStorage.setItem('currentUser', JSON.stringify(user));
            this.updateUI();
            this.closeLoginModal();
            this.showNotification(`مرحباً بعودتك، ${user.name}!`, 'success');
        } else {
            this.showNotification('اسم المستخدم أو كلمة المرور غير صحيحة!', 'error');
        }
    }

    // تحديث الواجهة
    updateUI() {
        const userNameElement = document.getElementById('userName');
        const userBalanceElement = document.getElementById('userBalance');
        const currentBalanceElement = document.getElementById('currentBalance');
        const loginBtn = document.getElementById('loginBtn');

        if (this.currentUser) {
            if (userNameElement) userNameElement.textContent = this.currentUser.name;
            if (userBalanceElement) userBalanceElement.textContent = this.currentUser.balance.toFixed(2) + ' ريال';
            if (currentBalanceElement) currentBalanceElement.innerHTML = `${this.currentUser.balance.toFixed(2)} <span>ريال</span>`;
            if (loginBtn) loginBtn.style.display = 'none';
        } else {
            if (userNameElement) userNameElement.textContent = 'زائر';
            if (userBalanceElement) userBalanceElement.textContent = '0.00 ريال';
            if (currentBalanceElement) currentBalanceElement.innerHTML = '0.00 <span>ريال</span>';
            if (loginBtn) loginBtn.style.display = 'block';
        }
        
        this.displayProducts();
    }

    // عرض المنتجات
    displayProducts() {
        const grid = document.getElementById('productsGrid');
        if (!grid) return;

        grid.innerHTML = '';

        this.products.forEach(product => {
            if (product.status === 'active') {
                const productCard = document.createElement('div');
                productCard.className = 'product-card';
                productCard.innerHTML = this.createProductHTML(product);
                grid.appendChild(productCard);
            }
        });
    }

    // إنشاء HTML للمنتج
    createProductHTML(product) {
        const canBuy = this.currentUser && this.currentUser.balance >= product.price;
        
        return `
            <div class="product-header">
                <div class="product-icon" style="background: linear-gradient(45deg, ${product.color}, ${product.color}99)">
                    <i class="fas ${product.icon}"></i>
                </div>
                <div class="product-info">
                    <h4>${product.name}</h4>
                    <span class="product-category">${product.category}</span>
                </div>
            </div>
            <p class="product-description">${product.description}</p>
            <div class="product-price">${product.price.toFixed(2)} ريال</div>
            <button class="buy-btn" onclick="storeApp.preparePurchase(${product.id})" 
                ${!this.currentUser || !canBuy ? 'disabled' : ''}>
                <i class="fas fa-shopping-cart"></i> 
                ${this.currentUser ? (canBuy ? 'شراء الآن' : 'رصيد غير كافي') : 'سجل الدخول للشراء'}
            </button>
        `;
    }

    // تجهيز عملية الشراء
    preparePurchase(productId) {
        if (!this.currentUser) {
            this.showLoginModal();
            return;
        }

        const product = this.products.find(p => p.id === productId);
        if (!product) return;

        if (this.currentUser.balance >= product.price) {
            this.showPurchaseModal(product);
        } else {
            this.showNotification('رصيدك غير كافي لشراء هذا المنتج!', 'error');
        }
    }

    // عرض نافذة الشراء
    showPurchaseModal(product) {
        const modal = document.getElementById('purchaseModal');
        const details = document.getElementById('purchaseDetails');
        
        if (!modal || !details) return;

        const newBalance = this.currentUser.balance - product.price;
        
        details.innerHTML = `
            <div style="text-align: center; padding: 20px 0;">
                <div class="product-icon" style="margin: 0 auto 15px; width: 60px; height: 60px; background: linear-gradient(45deg, ${product.color}, ${product.color}99); border-radius: 12px; display: flex; align-items: center; justify-content: center; color: white; font-size: 1.5em;">
                    <i class="fas ${product.icon}"></i>
                </div>
                <h4>${product.name}</h4>
                <p>${product.description}</p>
                <div class="product-price">${product.price.toFixed(2)} ريال</div>
                <p style="color: #666; margin-top: 10px;">
                    الرصيد الحالي: <strong>${this.currentUser.balance.toFixed(2)} ريال</strong><br>
                    الرصيد بعد الشراء: <strong style="color: ${newBalance >= 0 ? '#4CAF50' : '#f44336'}">${newBalance.toFixed(2)} ريال</strong>
                </p>
            </div>
        `;
        
        modal.style.display = 'block';
        this.currentProduct = product;
    }

    // تأكيد الشراء
    confirmPurchase() {
        if (!this.currentUser || !this.currentProduct) return;

        if (this.currentUser.balance >= this.currentProduct.price) {
            // خصم المبلغ من رصيد المستخدم
            this.currentUser.balance -= this.currentProduct.price;
            
            // تحديث المستخدم في localStorage
            const userIndex = this.users.findIndex(u => u.id === this.currentUser.id);
            if (userIndex !== -1) {
                this.users[userIndex].balance = this.currentUser.balance;
                localStorage.setItem('users', JSON.stringify(this.users));
                localStorage.setItem('currentUser', JSON.stringify(this.currentUser));
            }

            // إنشاء طلب جديد
            const newOrder = {
                id: Date.now(),
                userId: this.currentUser.id,
                userName: this.currentUser.name,
                productId: this.currentProduct.id,
                productName: this.currentProduct.name,
                productPrice: this.currentProduct.price,
                totalPrice: this.currentProduct.price,
                status: 'pending',
                date: new Date().toLocaleDateString('ar-EG'),
                time: new Date().toLocaleTimeString('ar-EG')
            };

            this.orders.push(newOrder);
            localStorage.setItem('orders', JSON.stringify(this.orders));

            // إشعار النجاح
            this.showNotification(`تم الشراء بنجاح! تم خصم ${this.currentProduct.price.toFixed(2)} ريال`, 'success');
            
            // تحديث الواجهة
            this.updateUI();
            this.closePurchaseModal();

            // محاكاة اكتمال الطلب بعد 5 ثواني
            setTimeout(() => this.completeOrder(newOrder.id), 5000);

        } else {
            this.showNotification('رصيدك غير كافي!', 'error');
        }
    }

    // اكتمال الطلب (محاكاة)
    completeOrder(orderId) {
        const orderIndex = this.orders.findIndex(order => order.id === orderId);
        if (orderIndex !== -1 && this.orders[orderIndex].status === 'pending') {
            this.orders[orderIndex].status = 'completed';
            localStorage.setItem('orders', JSON.stringify(this.orders));
            this.showNotification(`تم اكتمال طلبك #${orderId} بنجاح!`, 'success');
        }
    }

    // إضافة رصيد
    addBalance(amount) {
        if (this.currentUser) {
            this.currentUser.balance += amount;
            
            // تحديث المستخدم في localStorage
            const userIndex = this.users.findIndex(u => u.id === this.currentUser.id);
            if (userIndex !== -1) {
                this.users[userIndex].balance = this.currentUser.balance;
                localStorage.setItem('users', JSON.stringify(this.users));
                localStorage.setItem('currentUser', JSON.stringify(this.currentUser));
            }

            this.updateUI();
            this.closeAddBalanceModal();
            this.showNotification(`تم إضافة ${amount} ريال إلى رصيدك!`, 'success');
        } else {
            this.showNotification('يجب تسجيل الدخول أولاً!', 'error');
            this.showLoginModal();
        }
    }

    // الدوال المساعدة للنوافذ
    showLoginModal() {
        const modal = document.getElementById('loginModal');
        if (modal) modal.style.display = 'block';
    }

    closeLoginModal() {
        const modal = document.getElementById('loginModal');
        if (modal) {
            modal.style.display = 'none';
            const form = document.getElementById('loginForm');
            if (form) form.reset();
        }
    }

    showAddBalanceModal() {
        if (this.currentUser) {
            const modal = document.getElementById('addBalanceModal');
            if (modal) modal.style.display = 'block';
        } else {
            this.showNotification('يجب تسجيل الدخول أولاً!', 'error');
            this.showLoginModal();
        }
    }

    closeAddBalanceModal() {
        const modal = document.getElementById('addBalanceModal');
        if (modal) modal.style.display = 'none';
    }

    closePurchaseModal() {
        const modal = document.getElementById('purchaseModal');
        if (modal) {
            modal.style.display = 'none';
            this.currentProduct = null;
        }
    }

    showNotification(message, type = 'info') {
        // إنشاء إشعار بسيط
        alert(message);
    }

    // تسجيل الخروج
    logout() {
        this.currentUser = null;
        localStorage.removeItem('currentUser');
        this.updateUI();
        this.showNotification('تم تسجيل الخروج بنجاح', 'info');
    }
}

// الدوال العامة للواجهة
function fillDemoAccount(username, password) {
    const usernameInput = document.getElementById('loginUsername');
    const passwordInput = document.getElementById('loginPassword');
    
    if (usernameInput && passwordInput) {
        usernameInput.value = username;
        passwordInput.value = password;
    }
}

function addBalance(amount) {
    if (storeApp) {
        storeApp.addBalance(amount);
    }
}

// تهيئة التطبيق عند تحميل الصفحة
let storeApp;

document.addEventListener('DOMContentLoaded', function() {
    storeApp = new StoreApp();
});